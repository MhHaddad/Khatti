//
//  MemoCell.swift
//  Khatti5
//
//  Created by Raghad Omar on 9/16/21
//

import UIKit

class MemoCell: UITableViewCell {
    
    //componant of cell
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var date: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
    
}
