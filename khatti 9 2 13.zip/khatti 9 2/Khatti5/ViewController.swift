//
//  ViewController.swift
//  Khatti5
//
// Created by Raghad Omar on 9/16/21.
//

import UIKit
import SwiftSignatureView
import SCLAlertView
import Alamofire
import KRProgressHUD
import PencilKit
import CoreData

class ViewController: UIViewController,  UIColorPickerViewControllerDelegate{
    
    
    
    @IBOutlet weak var fontStp: UIStepper!
    @IBOutlet weak var pickColorBtn: UIButton!
    @IBOutlet weak var penSizeSlider: UISlider!
    @IBOutlet weak var drawingView: SwiftSignatureView!
    @IBOutlet weak var userText: UITextView!
    @IBOutlet weak var btnSend: UIButton!
    @IBOutlet var homebutton: UIButton!
    @IBOutlet var textSize: UILabel!
    
    let picker = UIColorPickerViewController()
    var points = [CGPoint]()
    var strokes = [PKStroke]()
    var pencilkitsignature = PencilKitSignatureView()
    var selectedTitle = String()
    var editDrawing = false
    var passData = ""
    var passDataInt = -1
    var btnCompareHidden = false
    var btnHomeHidden = false
    var fontStpHidden = false
    var textSizeHidden = false
    
    
    fileprivate var items: [String]!
    fileprivate let appDelegate = UIApplication.shared.delegate as! AppDelegate //??
    
    
    // to go to home from canvas
    @IBAction func homebutton(_ sender: Any) {
        self.view.window?.rootViewController?.dismiss(animated: true, completion: nil)
    }
    
    // to make text size bigger and smaller
    @IBAction func fontStepper(_ sender: UIStepper) {
        self.userText.font = self.userText.font?.withSize(CGFloat(sender.value))
        fontStp.value = sender.value
        
    }
    // to clear canvas
    @IBAction func didTapClear() {
        drawingView.clear()
    }
    
    // to undo stroke
    @IBAction func didTapUndo(_ sender: Any) {
        drawingView.undo()
    }
    // to show color picker
    @IBAction func pickColor(_ sender: Any) {
        self.present(picker, animated: true, completion: nil)
    }
    // to make stroke thiker or thiner
    @IBAction func penSize(_ sender: UISlider) {
        self.drawingView.maximumStrokeWidth = CGFloat(Int(sender.value))
    }
    
    override func viewWillAppear(_ animated: Bool) {
        btnSend.isHidden = btnCompareHidden
        homebutton.isHidden = btnHomeHidden
        fontStp.isHidden = fontStpHidden
        textSize.isHidden = textSizeHidden
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // to hide home button, comparing button,text size stepper when it's come from saved session
        btnSend.isHidden = false
        homebutton.isHidden = false
        fontStp.isHidden = false
        textSize.isHidden = false
        
        //retrive data from enter text and sample view controller class
        userText.text = passData
        
        
        if passDataInt == 0 {
            self.userText.font = UIFont(name: "Diwani Letter", size: 65)
        } else if passDataInt == 1 {
            self.userText.font = UIFont(name: "Mishafi", size: 65)
        } else if passDataInt == 2 {
            self.userText.font = UIFont(name: "Aref Ruqaa", size: 65)
        }else {
            self.userText.font = UIFont(name: "NotoNastaliqUrdu", size: 65)
        }
        
        
        
        self.pencilkitsignature = self.drawingView.subviews[0] as! PencilKitSignatureView
        
        
        fontStp.value = Double(Int(self.userText.font?.pointSize ?? 50))
        
        self.penSizeSlider.value = Float(self.drawingView.maximumStrokeWidth)
        
        picker.selectedColor = self.drawingView.strokeColor
        picker.delegate = self
        
        if self.editDrawing{
            self.pencilkitsignature.canvas.drawing = self.LoadDrawing(data: self.retrieveDrawingData(title: self.selectedTitle) as Data)
        }
        
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = appDelegate.persistentContainer.viewContext
    }// end view did load
    
    
    
    // functions color picker ??
    func colorPickerViewControllerDidFinish(_ viewController: UIColorPickerViewController) {
        self.drawingView.strokeColor = picker.selectedColor
        self.pickColorBtn.tintColor = picker.selectedColor
    }
    func colorPickerViewController(_ viewController: UIColorPickerViewController, didSelect color: UIColor, continuously: Bool) {
        self.drawingView.strokeColor = picker.selectedColor
        self.pickColorBtn.tintColor = picker.selectedColor
    }
    
    // button to send inbut data to cloudmirsaive API
    @IBAction func btnSend(_ sender: Any) {
        
        //alart user for empty canvas
        if drawingView.isEmpty{
            
            let alert = UIAlertController(title: "تنبيه!", message: "يجب ان تكتب بالقلم لترى المقارنة", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "حسنًا", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            return
            
        }else{
            KRProgressHUD.show(withMessage: "جاري المقارنة...")
            
            //convert text to image
            UIGraphicsBeginImageContextWithOptions(userText.bounds.size, false, UIScreen.main.scale)
            userText.drawHierarchy(in: userText.bounds, afterScreenUpdates: true)
            let textImage = UIGraphicsGetImageFromCurrentImageContext()!
            
            
            //convert stroke to image
            UIGraphicsBeginImageContextWithOptions(drawingView.bounds.size, false, UIScreen.main.scale)
            drawingView.drawHierarchy(in: drawingView.bounds, afterScreenUpdates: true)
            let drawingImage = UIGraphicsGetImageFromCurrentImageContext()!
            
            
            
            //save img as png and get path
            let urlImg1 = self.saveImage(textImage, name: "img1.png")!.path
            let urlImg2 = self.saveImage(drawingImage, name: "img2.png")!.path
            
            
            // set parametr of API
            let params = [
                [
                    "key": "baseImage",
                    "src": urlImg1,
                    "type": "file"
                ],
                [
                    "key": "comparisonImage",
                    "src": urlImg2,
                    "type": "file"
                ]] as [[String : Any]]
            
            let headers:HTTPHeaders = [
                "recognitionMode": "Basic",
                "Content-Type": "multipart/form-data",
                "Apikey":"7e868607-a86f-4bec-a638-56547450218e"
            ]
            AF.upload(multipartFormData:
                        {
                //compriess the images to speed up the prosses
                (multipartFormData) in
                multipartFormData.append(textImage.jpegData(compressionQuality: 1)!, withName: "baseImage", fileName: "img1.png", mimeType: "file")
                multipartFormData.append(drawingImage.jpegData(compressionQuality: 1)!, withName: "comparisonImage", fileName: "img2.png", mimeType: "file")
                for param in params{
                    for (key, value) in param
                    {
                        multipartFormData.append((value as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key)
                    }
                }
                //send and get response of Similarity Score
            }, to:"https://api.cloudmersive.com/image/recognize/similarity/compare",headers:headers).responseJSON{ (response) in
                if case .success ( _) = response.result {
                    print("DATA UPLOAD SUCCESSFULLY: \(response.result)")
                    guard let data = response.data else { return }
                    let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
                    let SimilarityScore = Int(((json!["ImageSimilarityScore"]) as! Float)*100)
                    KRProgressHUD.dismiss {
                        SCLAlertView().showInfo("", subTitle: "نسبة التطابق هي :\(SimilarityScore)%")
                    }
                    
                }else{
                    KRProgressHUD.dismiss {
                        SCLAlertView().showWarning("", subTitle: "حدثت مشكلة حاول مرة اخرى")
                    }
                }
            }
            
        }
    }
    
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
    }
    
    // function to save strokes in core data
    @IBAction func saveDrawing(_ sender: Any) {
        
        if !self.editDrawing{
            _ = ""
            let alert = UIAlertController(title: "حفظ ؟", message: "ادخل اسم المخطوطة", preferredStyle: .alert)
            alert.addTextField{ (textField) in
                textField.text = ""
            }
            alert.addAction(UIAlertAction(title: "الغاء", style: .cancel))
            alert.addAction(UIAlertAction(title: "موافق", style: .default, handler: { [weak alert] (_) in
                
                let textField = alert!.textFields![0]
                if !textField.text!.isEmpty,!self.checkExistance(title: textField.text!){
                    self.createData(title: textField.text!)
                }
                
            }))
            
            self.present(alert, animated: true, completion: nil)
        }else{
            self.updateData(title: self.selectedTitle)
        }
    }
    
    
    // function to share strokes
    @IBAction func share(_ sender: Any) {
        
        let image = drawingView.getCroppedSignature()
        let imageShare = [ image! ]
        let activityViewController = UIActivityViewController(activityItems: imageShare , applicationActivities: nil)
        
        activityViewController.popoverPresentationController?.sourceView = (sender as! UIView)
        self.present(activityViewController, animated: true)
    }
    
    // saves an image, if save is successful, returns its URL on local storage
    func saveImage(_ image: UIImage, name: String) -> URL? {
        guard let imageData = image.jpegData(compressionQuality: 1) else {
            return nil
        }
        do {
            let imageURL = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first!.appendingPathComponent(name)
            try imageData.write(to: imageURL)
            return imageURL
        } catch {
            return nil
        }
    }
    
    // convert strokes to data
    func convertDrawingToData(pkdrawing: PKDrawing) -> Data {
        let data = pkdrawing.dataRepresentation()
        return data
    }
    
    // load strokes
    func LoadDrawing(data: Data) -> PKDrawing {
        
        var loadedDrawing: PKDrawing
        
        do {
            try loadedDrawing = PKDrawing.init(data: data)
            return loadedDrawing
        } catch {
            print("Error loading drawing object")
            return PKDrawing()
        }
    }
    
    // create data of canvas
    func createData(title:String){
        
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = appDelegate.persistentContainer.viewContext
        let drawingEntity = NSEntityDescription.entity(forEntityName: "Drawing", in: managedContext)!
        
        let image = self.drawingView.signature
        
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm E, d MMM y"
        
        let drawing = NSManagedObject(entity: drawingEntity, insertInto: managedContext)
        drawing.setValue(title, forKeyPath: "title")
        drawing.setValue(formatter.string(from:Date()), forKeyPath: "last_edit")
        drawing.setValue(self.convertDrawingToData(pkdrawing: self.pencilkitsignature.canvas.drawing), forKey: "data")
        drawing.setValue(image?.pngData(), forKey: "previewimg")
        
        
        do {
            try managedContext.save()
            SCLAlertView().showSuccess("تم الحفظ بنجاح", subTitle: "")
            
            
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
        }
    }
    
  
    //
    func retrieveDrawingData(title:String) ->Data{
        
        var data = Data()
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Drawing")
        
        fetchRequest.predicate = NSPredicate(format: "title = %@", title)
        
        
        do {
            let result = try managedContext.fetch(fetchRequest) //creat array with spacfic title
            let object = result[0] as! NSManagedObject // index result will be the data of spacfic title
            data = object.value(forKey: "data") as! Data // get value of stroke data
            
        } catch {
            
            print("Failed")
        }
        return data // return the stroke
    }
    
    // chaking for existing title in core data
    func checkExistance(title:String) ->Bool{
        var exist = false
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Drawing")
        
        fetchRequest.predicate = NSPredicate(format: "title = %@", title)
        
        
        do {
            let result = try managedContext.fetch(fetchRequest)
            if result.count != 0{
                exist = true
                SCLAlertView().showError("اسم المخطوطة موجود سابقًا", subTitle: "")
            }
            
        } catch {
            
            print("Failed")
        }
        return exist
    }
    
    // update data for resaved canvas
    func updateData(title:String){
        
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest:NSFetchRequest<NSFetchRequestResult> = NSFetchRequest.init(entityName: "Drawing")
        
        fetchRequest.predicate = NSPredicate(format: "title = %@", title)
        
        do
        {
            let formatter = DateFormatter()
            formatter.dateFormat = "HH:mm E, d MMM y"
            
            let image = self.drawingView.signature
            
            let result = try managedContext.fetch(fetchRequest)
            let object = result[0] as! NSManagedObject
            object.setValue(formatter.string(from:Date()), forKeyPath: "last_edit")
            object.setValue(self.convertDrawingToData(pkdrawing: self.pencilkitsignature.canvas.drawing), forKey: "data")
            object.setValue(image?.pngData(), forKey: "previewimg")
            
            do{
                try managedContext.save()
                SCLAlertView().showSuccess("تم الحفظ بنجاح", subTitle: "")
            }
            catch
            {
                print(error)
            }
        }
        catch
        {
            print(error)
        }
        
    }
    
    
}
