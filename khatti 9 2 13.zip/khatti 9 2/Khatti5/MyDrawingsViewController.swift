//
//  MyDrawingsViewController.swift
//  Khatti5
//
// Created by Raghad Omar on 9/16/21
//

import UIKit
import CoreData
import SCLAlertView

class MyDrawingsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    
    @IBOutlet weak var table: UITableView!
    var titles = [String]()
    var previeImages = [Data]()
    var dates = [String]()
    var selectedTitle = String(){
        didSet{
            self.performSegue(withIdentifier: "Draw", sender: self)
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        self.table.dataSource = self
        self.table.delegate = self
        self.table.register(UINib(nibName: "MemoCell", bundle: nil), forCellReuseIdentifier: "memoCell")
        self.retrieveData()
        self.table.reloadData()
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.retrieveData()
    }
    
    // return count of table
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        self.titles.count
    }
    
    // to return canvas information
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "memoCell", for: indexPath) as! MemoCell
        cell.img.image = UIImage(data:self.previeImages[indexPath.row])
        cell.title.text = self.titles[indexPath.row]
        cell.date.text = self.dates[indexPath.row]
        
        return cell
    }
    
    // title
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.selectedTitle = self.titles[indexPath.row]
    }
    
    //swipe row to delete
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            self.deleteData(title: self.titles[indexPath.row])
        }
    }
    
    // update table
    func retrieveData() {
        
        self.titles.removeAll()
        self.dates.removeAll()
        self.previeImages.removeAll()
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Drawing")
        
        do {
            let result = try managedContext.fetch(fetchRequest)
            for data in result as! [NSManagedObject] {
                self.titles.append(data.value(forKey: "title") as! String)
                self.dates.append(data.value(forKey: "last_edit") as! String)
                self.previeImages.append(data.value(forKey: "previewimg") as! Data)
            }
            self.table.reloadData()
            
        } catch {
            
            print("Failed")
        }
    }
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "Draw" {
            let dest = segue.destination as! ViewController
            dest.editDrawing = true
            dest.selectedTitle = self.selectedTitle
            dest.btnCompareHidden = true
            dest.btnHomeHidden = true
            dest.fontStpHidden = true
            dest.textSizeHidden = true
        }
    }
    
    // function to delete saved canvas
    func deleteData(title:String){
        
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Drawing")
        
        fetchRequest.predicate = NSPredicate(format: "title = %@", title)
        
        do{
            let test = try managedContext.fetch(fetchRequest)
            let objectToDelete = test[0] as! NSManagedObject
            managedContext.delete(objectToDelete)
            
            do{
                try managedContext.save()
                SCLAlertView().showSuccess("تم الحذف بنجاح", subTitle: "")
                self.titles.removeAll()
                self.dates.removeAll()
                self.previeImages.removeAll()
                self.retrieveData()
            }
            catch
            {
                print(error)
            }
            
        }catch{
            print(error)
        }
        self.table.reloadData()
        
    }
    
}
