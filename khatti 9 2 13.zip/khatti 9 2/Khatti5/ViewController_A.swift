//
//  ViewController_A.swift
//  Khatti5
//
//  Created by Noura on 11/02/1443 AH.
//

import UIKit

class ViewController_A: UIViewController {


    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    
    }

  struct FontDesign: View {
     var body: some View {
        NavigationView {
            VStack(spacing: 10) {
                Text("Default font design")
                        .font(Font.system(size:30, design: .default))
                Divider()
                Text("Monospaced font design")
                    .font(Font.system(size:30, design: .monospaced))
                Divider()
                Text("Rounded font design")
                    .font(Font.system(size:30, design: .rounded))
                Divider()
                Text("Serif font design")
                    .font(Font.system(size:30, design: .serif))
                Divider()
                
                .navigationBarTitle(Text("Design"))
            }.padding()
        }
     }
    }
    

    struct TextStyle: View {
     var body: some View {
        NavigationView {
            VStack(spacing:10) {
                Text("Large Title").font(.largeTitle)
                Text("Title").font(.title)
                Text("Headline").font(.headline)
                Text("SubHeadline").font(.subheadline)
                Text("Body").font(.body)
                Text("Callout").font(.callout)
                Text("Caption").font(.caption)
                Text("FootNote").font(.footnote)
            }
        .navigationBarTitle(Text("Text Styles"))
        }
      }
    }

    struct WeightStyle: View {
     var body: some View {
        NavigationView {
            VStack(spacing:10) {
                Text("Ultralight").fontWeight(.ultraLight)
                Text("Thin").fontWeight(.thin)
                Text("Light").fontWeight(.light)
                Text("Regular").fontWeight(.regular)
                Text("Medium").fontWeight(.medium)
                Text("SemiBold").fontWeight(.semibold)
                Text("Bold").fontWeight(.bold)
                VStack(spacing:10) {
                    Text("Heavy").fontWeight(.heavy)
                    Text("Black").fontWeight(.black)
                }
            }
        .navigationBarTitle(Text("Weight"))
        }
      }
    }


    struct ContentView: View {
      @State var selectedTab = 0
      var body: some View {
         TabView(selection:$selectedTab) {
            TextStyle().tabItem {
               Image(systemName: "textformat")
                Text("Styles")
            }.tag(0)
            WeightStyle().tabItem {
                Image(systemName: "bold")
                Text("Weight")
            }.tag(1)
            FontDesign().tabItem {
                          Image(systemName: "text.cursor")
                          Text("Design")
                      }.tag(2)
          }
       }
    }

    
    

}
