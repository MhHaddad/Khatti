//
//  ChooseSampleViewController.swift
//  Khatti5
//
//  Created by Raghad Omar on 12/16/21.
//
import UIKit
import SwiftUI


class ChooseSampleViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate {
    
    
    
    @IBOutlet var selectFont: UITextField!
    @IBOutlet var selectSampleText: UITextField!
    @IBOutlet var userText: UITextView!
    @IBOutlet var btnSend: UIButton!
    
    
    let fontsNames = ["خط الديوان","خط النسخ","خط الرقعة","خط الثلث"]
    let fonts = ["Diwani Letter","Mishafi","Aref Ruqaa","NotoNastaliqUrdu"]
    let pickerFont = UIPickerView()
    let toolBar = UIToolbar()
    let btnDone = UIBarButtonItem()
    
    var sampleText = ["برنامج خطي","الخط حُليّة الكاتب ", "الخط لسان اليد وترجمان الإنسان!","إن جودت قلمك، جودّت خطك","الخط الحسن يزيد الحق وضوحًا"]
    var pickerSample = UIPickerView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        self.selectSampleText.text = sampleText[0]
        self.selectFont.text = fontsNames[0]
        self.userText.text = sampleText[0]
        self.userText.font = UIFont(name: "Diwani Letter", size: 40)
        
        pickerSample.delegate = self
        pickerSample.dataSource = self
        selectSampleText.inputView = pickerSample
        
        pickerFont.delegate = self
        pickerFont.dataSource = self
        selectFont.inputView = pickerFont
        
        
        btnDone.title = "تم"
        btnDone.action = #selector(btnDone(sender: ))
        toolBar.sizeToFit()
        toolBar.setItems([btnDone], animated: true)
        selectFont.inputAccessoryView = toolBar
        selectSampleText.inputAccessoryView = toolBar
        
        selectSampleText.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
    }
    
    // function to pass data index of font name and pass text
    @IBAction func btnSend(_ sender: Any) {
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "ViewControllered") as! ViewController
        
        vc.passData = userText.text
        
        if selectFont.text == fontsNames[0]{
            vc.passDataInt = 0
        } else if selectFont.text == fontsNames[1] {
            vc.passDataInt = 1
        } else if selectFont.text == fontsNames[2] {
            vc.passDataInt = 2
        } else {
            vc.passDataInt = 3
        }
        
        present(vc, animated: true, completion: nil)
    }
    
    // function to dissmiss
    @objc func btnDone(sender: UIBarButtonItem) {
        view.endEditing(true)
    }
    
    //hide keybourd
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    
    // text veiw present sample text
    @objc func textFieldDidChange(_ textField: UITextField) {
        userText.text = selectSampleText.text
    }
    
    //return the picked
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    // to retrive data in pickerview
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView == pickerSample {
            return self.sampleText[row]
        } else if pickerView == pickerFont {
            return self.fontsNames[row]
        } else{
            return ""
        }
    }
    
    // return the selected data
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView == pickerSample {
            self.selectSampleText.text = self.sampleText[row]
            userText.text = selectSampleText.text
            self.selectSampleText.text = self.sampleText[row]
            self.selectSampleText.resignFirstResponder()
        }
        if pickerView == pickerFont {
            self.selectFont.text = self.fontsNames[row]
            self.userText.font = UIFont(name: self.fonts[row], size: 40)
            self.selectFont.resignFirstResponder()
        }
    }
    
    //return number of rows
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == pickerSample {
            return sampleText.count
        } else if pickerView == pickerFont {
            return fontsNames.count
        }
        
        return 1
    }
}

