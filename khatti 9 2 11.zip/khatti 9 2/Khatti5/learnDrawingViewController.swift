//
//  learnDrawingViewController.swift
//  Khatti5
//
//  Created by Raghad Omar on 9/16/21
//

import UIKit

class learnDrawingViewController: UIViewController{
    
    
    // linkes id
    let vidURLs = ["7N-JLZLnSrQ","cNDMsKawp10","X2g8ZuAPClE", //ruqaa
                   "qTA5KcdhdmE","8txc7CBMs2o&list","KF7TdhLX8g0&list",//diwani
                   "R3iqGSHuiD0","SiJcBmTzpsg","ToiJaRThCFk",//tholouth
                   "UA3JK6msA6o&list","IAn85PWRt88&list","d1bBJj_wDxA&list"]//naskh
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    // linke with every button tag
    @IBAction func watchVid(_ sender: UIButton) {
        var youtubeUrl = NSURL(string:"https://www.youtube.com/watch?v=\(vidURLs[sender.tag])")!
        
        if UIApplication.shared.canOpenURL(youtubeUrl as URL){
            UIApplication.shared.open(youtubeUrl as URL)
        } else{
            youtubeUrl = NSURL(string:" youtube://\(vidURLs[sender.tag])")!
            UIApplication.shared.open(youtubeUrl as URL)
        }
    }
    
    
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
    }
}
