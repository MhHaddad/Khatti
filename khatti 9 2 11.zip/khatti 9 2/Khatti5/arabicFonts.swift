//
//  arabicFonts.swift
//  Khatti5
//
//  Created by Noura on 15/03/1443 AH.
//

import UIKit

let persistFontKey = "font"

class arabicFonts: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    
    
    lazy var exo: UIFont = {
        let font = UIFont (
            id: 1,
            familyName: "Exo",
            defaultFont: "Exo-Regular",
            ultraLight: "Exo-Thin",
            thin: "Exo-ExtraLight",
            light: "Exo-Light",
            regular: "Exo-Regular",
            medium: "Exo-Medium",
            semibold: "Exo-Semibold",
            bold: "Exo-Bold",
            heavy: "Exo-ExtraBold",
            black: "Exo-Black"
        )
        return font
    }()
    
    
    lazy var taviraj: AppFont = {
        let font = AppFont(plist: "taviraj")
        return font
    }()

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // load fonts in main bundle
        FontBlaster.blast { fonts in
            print(fonts)
        }
        UIFont.printAllFonts()

        if let savedFont = UserDefaults.standard.string(forKey: persistFontKey) {
            switch savedFont {
            case exo.familyName:
                FontManager.shared.currentFont = exo
                break
            case taviraj.familyName:
                FontManager.shared.currentFont = taviraj
                break
            default:
                break
            }
        }

        return true
    }

}
