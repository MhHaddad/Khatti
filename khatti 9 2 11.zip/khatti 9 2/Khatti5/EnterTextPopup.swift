//
//  EnterTextPopup.swift
//  Khatti5
//
//  Created by Raghad Omar on 9/16/21
//


import UIKit
import SwiftUI

class EnterTextPopup: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate {
    
    @IBOutlet weak var selectFont: UITextField!
    @IBOutlet weak var enterText: UITextField!
    @IBOutlet weak var userText: UITextView!
    @IBOutlet weak var btnSend: UIButton!
    
    let fontsNames = ["خط الديوان","خط النسخ","خط الرقعة","خط الثلث"]
    let fonts = ["Diwani Letter","Mishafi","Aref Ruqaa","NotoNastaliqUrdu"]
    let pickerFont = UIPickerView()
    let toolBar = UIToolbar()
    let btnDone = UIBarButtonItem()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.selectFont.text = self.fontsNames[0]
        self.userText.font = UIFont(name: "Diwani Letter", size: 40)
        
        pickerFont.delegate = self
        pickerFont.dataSource = self
        selectFont.inputView = pickerFont
        enterText.delegate = self
        btnDone.title = "تم"
        btnDone.action = #selector(btnDone(sender: ))
        toolBar.sizeToFit()
        toolBar.setItems([btnDone], animated: true)
        selectFont.inputAccessoryView = toolBar
        
        enterText.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
    }
    
    // function to pass data index of font name and pass text
    @IBAction func btnSend(_ sender: Any) {
        if enterText.text == "" {
            checkMandatoryFields()
            
        }else {
            let vc = storyboard?.instantiateViewController(withIdentifier: "ViewControllered") as! ViewController
            vc.passData = userText.text
            if selectFont.text == fontsNames[0]{
                vc.passDataInt = 0
            } else if selectFont.text == fontsNames[1] {
                vc.passDataInt = 1
            } else if selectFont.text == fontsNames[2] {
                vc.passDataInt = 2
            } else {
                vc.passDataInt = 3
            }
            navigationController?.pushViewController(vc, animated: true)
            present(vc, animated: true, completion: nil)
        }
    }
    
    //dissmiss 
    @objc func btnDone(sender: UIBarButtonItem) {
        view.endEditing(true)
    }
    
    //hide keybourd
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true)
    }
    
    // text veiw present enter text
    @objc func textFieldDidChange(_ textField: UITextField) {
        userText.text = enterText.text
    }
    
    // return the picked
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    // to retrive data in pickerview
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        self.fontsNames[row]
    }
    
    //return selected data
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.selectFont.text = self.fontsNames[row]
        self.userText.font = UIFont(name: self.fonts[row], size: 65)
        
    }
    
    //number of rows
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        self.fontsNames.count
    }
    
    
    //chacking for empty field
    func checkMandatoryFields(){
        if let sentence = enterText.text, sentence.isEmpty {
            print("تنبيه! ")
            let alert = UIAlertController(title: "تنبيه!", message: "الرجاء ادخال جملة", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "حسنًا", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
            return
        }
    }
    
    
    // chacking for arabic charachter
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == self.enterText {
            
            let arabChars = ["ا","ب","ت","ث","ج","ح","خ","د","ذ","ر","ز","س","ش","ص","ض","ط","ظ","ع","غ","ف","ق","ك","ل","م","إ","أ","آ","ى","ؤ","ئ","لأ","لإ","(",")","؟","{","}",".","،","*","!","/","ـ","","ن","","ه","و","ي","ء"," ","ْ","ٌ","ُ","ٍ","ِ","ً","َ","ّ","١","٢","٣","٤","٥","٦","٧","٨","٩","٠", "ة"]
            if arabChars.contains(string){
                return true
            }else {
                
                let alert = UIAlertController(title: "تنبيه!", message: "الرجاء ادخال حروف عربية ", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "حسنًا", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                
                return false
            }
        }else {
            return true
        }
    }
}
